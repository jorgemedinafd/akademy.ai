from numpy import random

rolls = random.randint(low=1, high=6, size=10)
print(rolls)
print(type(rolls))