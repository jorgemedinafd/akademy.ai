from file1 import func, test
from datetime import datetime

now = datetime.now().time()
print("now =", now)

func(3,4)

test(10,0)