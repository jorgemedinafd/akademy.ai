def func(a,b):
	print(a*b)

def test(a,b):
	if a > 5 or b > 5:
		print("You have passed the exam")